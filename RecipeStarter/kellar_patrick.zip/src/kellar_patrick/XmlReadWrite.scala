package kellar_patrick

import scala.xml.*

trait XmlReadWrite {
    def loadXml(node: Node): Unit = {}
    def writeXml(): Elem = {null}
}

